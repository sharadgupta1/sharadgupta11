class TestMiddleware {
  middleware () {}
}

module.exports = TestMiddleware
